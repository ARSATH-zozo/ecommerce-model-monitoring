# Data Dictionary

| Field | Description |
|---|---|
| event_id | Unique recommendation event |
| timestamp | Event timestamp |
| user_id | Synthetic user identifier |
| product_id | Synthetic product identifier |
| experiment_id | Recommendation experiment |
| recommendation_score | Model recommendation score |
| user_age | User age |
| session_length | Session duration |
| previous_purchases | Historical purchase count |
| product_price | Recommended product price |
| category | Product category |
| device_type | User device |
| traffic_source | Acquisition source |
| predicted_click_probability | Model probability |
| actual_clicked | Observed click outcome |
| actual_purchased | Observed purchase outcome |
| conversion_value | Revenue associated with purchase |
| model_version | Model deployment version |
