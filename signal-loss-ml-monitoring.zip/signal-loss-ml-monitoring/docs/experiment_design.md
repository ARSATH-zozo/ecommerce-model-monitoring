# Experiment Design

The project uses reproducible synthetic e-commerce recommendation events.

Experiments include:
1. healthy production
2. early drift
3. gradual drift
4. harmful degradation
5. duplicate events
6. out-of-order events
7. delayed outcomes
8. missing data
9. noisy labels
10. drift without performance degradation
11. performance degradation without obvious drift
12. monitoring outage/recovery
