# Technical Approaches

## Approach A — PSI

Population Stability Index compares a reference distribution with a production distribution.

Strength:
- simple
- interpretable
- useful for feature drift

Limitation:
- drift does not always mean business-performance degradation.

## Approach B — Outcome-aware monitoring

Outcome monitoring compares observed recommendation outcomes with the healthy baseline.

Strength:
- directly connected to model performance.

Limitation:
- requires delayed outcome data.

## Hybrid

The selected design combines feature drift and outcome-aware performance so that both leading and lagging indicators are visible.
