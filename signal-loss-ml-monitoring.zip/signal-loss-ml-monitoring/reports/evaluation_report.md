# Evaluation Report

## Dataset

Raw rows: 25,150

Clean rows: 25,000

Duplicates removed: 150

## Model

Accuracy: 0.6956

Precision: 0.7058

Recall: 0.9036

ROC-AUC: 0.7302

## Monitoring

Two approaches were evaluated:
- PSI feature drift monitoring
- outcome-aware performance monitoring

A hybrid alert engine combines both signals.

## Reproducibility

Random seed: 42

All primary experiment results are generated from the synthetic dataset.
