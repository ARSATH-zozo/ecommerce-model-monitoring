# Signal Loss — ML Model Monitoring

## Overview

A reproducible capstone project for detecting recommendation-model performance degradation after deployment in an e-commerce environment.

## Pipeline

Raw Data → Cleaning → Model → Predictions → Delayed Outcomes → Drift Monitoring → Performance Monitoring → Alerts → Business Impact → Evaluation

## Dataset

Synthetic dataset containing 25,150 raw recommendation events.

After cleaning: 25,000 events.

## Machine Learning

Random Forest recommendation click model.

ROC-AUC: 0.7302

## Monitoring

### PSI

Detects changes in feature distributions.

### Outcome-aware monitoring

Detects degradation in observed recommendation outcomes.

### Hybrid

Combines both signals into NORMAL, WATCH and CRITICAL states.

## Edge Cases

- Duplicate events
- Out-of-order events
- Delayed outcomes
- Missing data
- Noisy labels
- Drift without performance degradation
- Performance degradation without obvious drift
- Monitoring outage and recovery

## Technologies

Python, Pandas, NumPy, Scikit-learn, SciPy, Joblib, Pytest, FastAPI.

## Reproducibility

Random seed: 42

The generated data and experiment results can be reproduced using the project pipeline.

## Important

This project uses synthetic data for experimentation and demonstration. It does not represent real customer data.
