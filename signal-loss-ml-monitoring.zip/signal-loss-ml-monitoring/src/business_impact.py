"""
Business impact estimation based on lost conversions and revenue.
"""

