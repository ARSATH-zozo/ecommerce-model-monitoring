"""
Reproducible synthetic e-commerce recommendation event generator.
Uses fixed random seed for repeatable experiments.
"""
SEED = 42

