"""
Main reproducible pipeline entry point.

Run:
    python scripts/run_all.py
"""

