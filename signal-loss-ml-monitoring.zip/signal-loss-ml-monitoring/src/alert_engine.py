"""
Hybrid monitoring alert engine.
Combines feature drift and outcome-aware degradation.
"""

