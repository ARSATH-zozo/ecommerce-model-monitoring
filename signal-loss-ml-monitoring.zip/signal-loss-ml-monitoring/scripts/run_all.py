"""
Reproduce the Signal Loss experiment pipeline.

The notebook used to generate the current artifacts contains
the complete implementation and fixed random seed.
"""
print("Run the main experiment notebook to regenerate artifacts.")
