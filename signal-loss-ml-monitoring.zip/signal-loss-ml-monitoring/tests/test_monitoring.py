import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_raw_dataset_exists():
    assert (ROOT / "data/raw/recommendation_events_raw.csv").exists()

def test_clean_dataset_exists():
    assert (ROOT / "data/processed/recommendation_events_clean.csv").exists()

def test_clean_dataset_has_no_missing_values():
    df = pd.read_csv(ROOT / "data/processed/recommendation_events_clean.csv")
    assert df.isna().sum().sum() == 0

def test_prediction_file_exists():
    assert (ROOT / "data/predictions/model_predictions.csv").exists()

def test_drift_results_exist():
    assert (ROOT / "results/drift_results.csv").exists()

def test_performance_results_exist():
    assert (ROOT / "results/performance_results.csv").exists()

def test_benchmark_exists():
    assert (ROOT / "results/benchmark_results.csv").exists()

def test_resilience_exists():
    assert (ROOT / "results/resilience_results.csv").exists()

def test_model_exists():
    assert (ROOT / "models/recommendation_model.pkl").exists()

def test_hybrid_alerts_exist():
    assert (ROOT / "results/hybrid_alerts.csv").exists()
